--[[--
This plugin processes dictionary word lookups and uses spaced repetition to help you remember new words.

@module koplugin.vocabbuilder
--]]--

local BD = require("ui/bidi")
local Blitbuffer = require("ffi/blitbuffer")
local BottomContainer = require("ui/widget/container/bottomcontainer")
local DB = require("flipside_db")
local Button = require("ui/widget/button")
local ButtonDialog = require("ui/widget/buttondialog")
local ButtonTable = require("ui/widget/buttontable")
local CenterContainer = require("ui/widget/container/centercontainer")
local ConfirmBox = require("ui/widget/confirmbox")
local Device = require("device")
local Dispatcher = require("dispatcher")
local Event = require("ui/event")
local Font = require("ui/font")
local FocusManager = require("ui/widget/focusmanager")
local FrameContainer = require("ui/widget/container/framecontainer")
local Geom = require("ui/geometry")
local GestureRange = require("ui/gesturerange")
local HorizontalGroup = require("ui/widget/horizontalgroup")
local HorizontalSpan = require("ui/widget/horizontalspan")
local IconButton = require("ui/widget/iconbutton")
local IconWidget = require("ui/widget/iconwidget")
local InfoMessage = require("ui/widget/infomessage")
local InputContainer = require("ui/widget/container/inputcontainer")
local InputDialog = require("ui/widget/inputdialog")
local LeftContainer = require("ui/widget/container/leftcontainer")
local LineWidget = require("ui/widget/linewidget")
local MovableContainer = require("ui/widget/container/movablecontainer")
local Notification = require("ui/widget/notification")
local RightContainer = require("ui/widget/container/rightcontainer")
local OverlapGroup = require("ui/widget/overlapgroup")
local Screen = Device.screen
local Size = require("ui/size")
local SortWidget = require("ui/widget/sortwidget")
local TextWidget = require("ui/widget/textwidget")
local TextBoxWidget = require("ui/widget/textboxwidget")
local TitleBar = require("ui/widget/titlebar")
local ToggleSwitch = require("ui/widget/toggleswitch")
local UIManager = require("ui/uimanager")
local VerticalGroup = require("ui/widget/verticalgroup")
local VerticalSpan = require("ui/widget/verticalspan")
local WidgetContainer = require("ui/widget/container/widgetcontainer")
local util = require("util")
local _ = require("gettext")
local C_ = _.pgettext
local T = require("ffi/util").template
local FlipSideMenuStyle = require("flipside_mainmenu_style")

local VocabBuilder = WidgetContainer:extend{
    name = "flipside",
    settings_key = "flipside",
}

-------- shared values
local word_face = Font:getFace("x_smallinfofont")
local subtitle_face = Font:getFace("cfont", 12)
local subtitle_italic_face = Font:getFace("NotoSans-Italic.ttf", 12)
local subtitle_color = Blitbuffer.COLOR_DARK_GRAY
local dim_color = Blitbuffer.COLOR_GRAY_3
local settings = G_reader_settings:readSetting(VocabBuilder.settings_key, {enabled = false, with_context = true})
-- Older saved settings may lack this field. Respect an explicit false, but
-- keep context saving ON when a previous version never created the option.
if settings.with_context == nil then settings.with_context = true end
-- Manual KOReader WordLookedUp belongs to the native plugin unless the
-- independent FlipSide button is actively processing its own request.
local flipSideManualLookup = false

--[[--
Menu dialogue widget
--]]--
local MenuDialog = FocusManager:extend{
    padding = Size.padding.large,
    is_edit_mode = false,
    edit_callback = nil,
    tap_close_callback = nil,
    clean_callback = nil,
    reset_callback = nil,
}

function MenuDialog:init()
    self.layout = {}
    if Device:hasKeys() then
        local back_group = util.tableDeepCopy(Device.input.group.Back)
        if Device:hasFewKeys() then
            table.insert(back_group, "Left")
        else
            table.insert(back_group, "Menu")
        end
        self.key_events.Close = { { back_group } }
    end
    if Device:isTouchDevice() then
        self.ges_events.Tap = {
            GestureRange:new {
                ges = "tap",
                range = Geom:new {
                    x = 0,
                    y = 0,
                    w = Screen:getWidth(),
                    h = Screen:getHeight(),
                }
            }
        }
    end
end

function MenuDialog:setupPluginMenu()
    -- Mark only FlipSide's main settings popup. This permits the flashcard
    -- module to remove navigation-mode rows injected by an obsolete userpatch,
    -- without touching unrelated KOReader dialogs or menu buttons.
    self._flipside_settings_popup = true
    local size = Screen:getSize()
    local safe = FlipSideMenuStyle.menuSafeBounds(size)
    local metrics = FlipSideMenuStyle.menuMetrics(size, safe.h)
    local width = math.floor(math.min(size.w, safe.w) * 0.9)

    -- Allocate the real label and switch widths before constructing any
    -- KOReader widgets. Both must fit inside the outer frame at every DPI.
    local switch_guide_width, switch_width = FlipSideMenuStyle.panelSizing(width, metrics)

    local switch = ToggleSwitch:new{
        width = switch_width,
        height = metrics.switch_height,
        font_size = 16,
        default_value = 2,
        name = "flipside",
        name_text = nil, --_("Accept new words"),
        event = "ChangeEnableStatus",
        args = {"off", "on"},
        default_arg = "on",
        toggle = { _("off"), _("on") },
        values = {1, 2},
        alternate = false,
        enabled = true,
        config = self,
        readonly = self.readonly,
    }
    switch:setPosition(settings.enabled and 2 or 1)
    self:mergeLayoutInVertical(switch)

    self.context_switch = ToggleSwitch:new{
        width = switch_width,
        height = metrics.switch_height,
        font_size = 16,
        default_value = 1,
        name_text = nil,
        event = "ChangeContextStatus",
        args = {"off", "on"},
        default_arg = "off",
        toggle = { _("off"), _("on") },
        values = {1, 2},
        alternate = false,
        enabled = true,
        config = self,
        readonly = self.readonly,
    }
    self.context_switch:setPosition(settings.with_context and 2 or 1)
    self:mergeLayoutInVertical(self.context_switch)

    local filter_button = {
        text = _("Filter books"),
        callback = function()
            self:onClose()
            self.vocabbuilder:onShowFilter()
        end
    }

    local edit_button = {
        text = self.is_edit_mode and _("Resume") or _("Quick deletion"),
        callback = function()
            self:onClose()
            self.edit_callback()
        end
    }

    local reset_button = {
        text = _("Reset all progress"),
        callback = function()
            UIManager:show(ConfirmBox:new{
                text = _("Reset progress of all words?"),
                ok_text = _("Reset"),
                ok_callback = function()
                    DB:resetProgress()
                    self:onClose()
                    self.reset_callback()
                end
            })
        end
    }

    local clean_button = {
        text = _("Clean all words"),
        callback = function()
            UIManager:show(ConfirmBox:new{
                text = _("Clean all words including progress?"),
                ok_text = _("Clean"),
                ok_callback = function()
                    local ok, err = pcall(DB.purge, DB)
                    if not ok then
                        UIManager:show(InfoMessage:new{
                            text = _("Clean cancelled: no words were removed. Could not create or verify the backup. Check available storage and KOReader logs."),
                        })
                        return
                    end
                    self:onClose()
                    self.clean_callback()
                end
            })
        end,
    }

    -- Configurations now live in Flashcards appearance > Sync settings.
    -- This single prominent button performs the exact same action as the
    -- one remaining Sync all gesture: the serialized coordinator.
    local sync_button = {
        text = _("Cloud sync"),
        callback = function()
            -- MenuDialog.vocabbuilder is the *window*, not the actual plugin.
            -- Pass the owning VocabBuilder instance, just like the Sync all
            -- Dispatcher gesture and the four independent Sync now actions.
            local widget = self.vocabbuilder
            local plugin = widget and widget.vocabbuilder
            self:onClose()
            if plugin then
                UIManager:nextTick(function()
                    plugin:onSyncFlipSideAll()
                end)
            end
        end,
    }
    local search_button = {
        text = _("Search"),
        callback = function()
            -- FlipSide hides the legacy list. Its native showSearchDialog()
            -- filters that invisible backing list, so no results are seen.
            -- Route searches to the visible flashcard-owned search dialog.
            self:onClose()
            UIManager:nextTick(function()
                local api = package.loaded["flipside_flashcards_menu_api"]
                local ok, opened = pcall(function()
                    return api and api.openSearch and api.openSearch()
                end)
                if not ok or not opened then
                    UIManager:show(InfoMessage:new{
                        text = _("Search is unavailable. Reopen FlipSide and try again."),
                        timeout = 4,
                    })
                end
            end)
        end
    }

    local buttons = FlipSideMenuStyle.makeActions(width, {
        {sync_button},
        {search_button},
        {filter_button, edit_button},
        {reset_button, clean_button},
    }, self, metrics)
    self:mergeLayoutInVertical(buttons)

    -- The popup catches taps across the full screen, but paints only its
    -- opaque panel within the measured space between the flashcard toolbars.
    self.covers_fullscreen = false
    self[1], self._flipside_settings_panel, self.cropping_widget =
        FlipSideMenuStyle.makeRoot(size,
            FlipSideMenuStyle.makeSwitchPanel(width, switch_guide_width,
                switch, self.context_switch, metrics),
            buttons, safe, metrics)
    -- Same measured-frame erasure as the Saved Meanings popup. Scoped to
    -- this main settings window; no change to the underlying card style.
    require("flipside_frame_cover").attach(self)
    self:refocusWidget()
end

function MenuDialog:setupBookMenu(sort_item, onSuccess)
    local size = Screen:getSize()
    local width = math.floor(size.w * 0.9)

    local change_title_button = {
        text = _("Change book title"),
        callback = function()
            self:onClose()
            -- first show_parent is sortWidget, second is vocabBuilderWidget
            self.show_parent.show_parent:showChangeBookTitleDialog(sort_item, onSuccess)
        end
    }
    local select_single_button = {
        text = _("Select only this book"),
        callback = function()
            self:onClose()
            for _, item in pairs(self.show_parent.item_table) do
                if item == sort_item then
                    if not item.checked_func() then
                        item.callback() -- toggle checkmark
                    end
                elseif item.checked_func() then
                    item.callback()
                end
            end
            self.show_parent:onGoToPage(self.show_parent.show_page)
        end
    }
    local select_all_button = {
        text = _("Select all books"),
        callback = function()
            self:onClose()
            for _, item in pairs(self.show_parent.item_table) do
                if not item.checked_func() then
                    item.callback()
                end
            end
            self.show_parent:onGoToPage(self.show_parent.show_page)
        end
    }
    local select_page_all_button = {
        text = _("Select all books on this page"),
        callback = function()
            self:onClose()
            for _, content in pairs(self.show_parent.main_content) do
                if content.item and not content.item.checked_func() then
                    content.item.callback()
                end
            end
            self.show_parent:onGoToPage(self.show_parent.show_page)
        end
    }
    local deselect_page_all_button = {
        text = _("Deselect all books on this page"),
        callback = function()
            self:onClose()
            for _, content in pairs(self.show_parent.main_content) do
                if content.item and content.item.checked_func() then
                    content.item.callback()
                end
            end
            self.show_parent:onGoToPage(self.show_parent.show_page)
        end
    }
    local buttons = ButtonTable:new{
        width = width,
        buttons = {
            {change_title_button},
            {select_single_button},
            {select_all_button},
            {select_page_all_button},
            {deselect_page_all_button},
        },
        show_parent = self
    }

    self.covers_fullscreen = true
    self[1] = CenterContainer:new{
        dimen = size,
        FrameContainer:new{
            padding = Size.padding.default,
            background = Blitbuffer.COLOR_WHITE,
            bordersize = Size.border.window,
            radius = Size.radius.window,
            buttons
        }
    }
end

function MenuDialog:onShow()
    if self._flipside_settings_popup then
        -- Repaint the flashcards first, then the opaque floating panel on top.
        -- A normal UI refresh avoids forcing a Kindle flash.
        UIManager:setDirty("all", "ui")
        return
    end
    UIManager:setDirty(self, function()
        return "ui", self[1][1].dimen -- FlipSide-owned menu: nonflashing update
    end)
end

function MenuDialog:onCloseWidget()
    if self._flipside_settings_popup then
        -- Restore the flashcard area previously hidden by the panel.
        UIManager:setDirty("all", "ui")
        return
    end
    UIManager:setDirty(nil, function()
        return "ui", self[1][1].dimen
    end)
end

function MenuDialog:onTap(_, ges)
    local panel = self._flipside_settings_popup and self._flipside_settings_panel
        or (self[1] and self[1][1])
    if panel and panel.dimen and ges.pos:notIntersectWith(panel.dimen) then
        -- Tap outside the *visible* panel closes the widget, at every DPI.
        self:onClose()
        return true
    end
end

function MenuDialog:onClose()
    UIManager:close(self)
    if self.tap_close_callback then
        self.tap_close_callback()
    end
    return true
end

function MenuDialog:onChangeContextStatus(args, position)
    settings.with_context = position == 2
end

function MenuDialog:onChangeEnableStatus(args, position)
    settings.enabled = position == 2
end

function MenuDialog:onConfigChoose(values, name, event, args, position)
    UIManager:tickAfterNext(function()
        if values then
            if event == "ChangeEnableStatus" then
                self:onChangeEnableStatus(args, position)
            elseif event == "ChangeContextStatus" then
                self:onChangeContextStatus(args, position)
            end
        end
        UIManager:setDirty(nil, "ui")
    end)
end

--[[--
Individual word info dialogue widget
--]]--
local WordInfoDialog = FocusManager:extend{
    word = nil,
    title = nil,
    highlighted_word = nil,
    book_title = nil,
    dates = nil,
    padding = Size.padding.large,
    margin = Size.margin.title,
    tap_close_callback = nil,
    remove_callback = nil,
    reset_callback = nil,
    update_callback = nil, -- used when duplicate word found when adding
    refresh_context_callback = nil, -- safe, context-only repair, no SRS change
    dismissable = true, -- set to false if any button callback is required
}
local book_title_triangle = BD.mirroredUILayout() and " ⯇" or " ⯈"
local word_info_dialog_width
function WordInfoDialog:init()
    self.layout = {}
    if self.dismissable then
        if Device:hasKeys() then
            local back_group = util.tableDeepCopy(Device.input.group.Back)
            if Device:hasFewKeys() then
                table.insert(back_group, "Left")
            else
                table.insert(back_group, "Menu")
            end
            self.key_events.Close = { { back_group } }
        end
        if Device:isTouchDevice() then
            self.ges_events.Tap = {
                GestureRange:new {
                    ges = "tap",
                    range = Geom:new {
                        x = 0,
                        y = 0,
                        w = Screen:getWidth(),
                        h = Screen:getHeight(),
                    }
                }
            }
        end
    end

    if not word_info_dialog_width then
        local temp_text = TextWidget:new{
            text = self.dates,
            padding = Size.padding.fullscreen,
            face = Font:getFace("cfont", 14)
        }
        local dates_width = temp_text:getSize().w
        temp_text:free()
        local screen_width = math.min(Screen:getWidth(), Screen:getHeight())
        word_info_dialog_width = math.floor(math.max(screen_width * 0.6, math.min(screen_width * 0.8, dates_width)))
    end
    local width = word_info_dialog_width
    local reset_button = {
        text = _("Reset progress"),
        callback = function()
            self.reset_callback()
            UIManager:close(self)
        end
    }
    local remove_button = {
        text = _("Remove word"),
        callback = function()
            self.remove_callback()
            UIManager:close(self)
        end
    }

    local forgot_button = {
        text = _("Forgot"),
        callback = function()
            self.forgot_callback()
            UIManager:close(self)
        end
    }

    local got_it_button = {
        text = _("Got it"),
        callback = function()
            self.got_it_callback()
            UIManager:close(self)
        end
    }

    local update_button = {
        text = _("Overwrite"),
        callback = function()
            self.update_callback()
            UIManager:close(self)
        end
    }

    local buttons = self.update_callback and {{got_it_button, forgot_button, update_button}} or {{reset_button, remove_button}}
    if self.refresh_context_callback then
        table.insert(buttons, {{
            text = "Restore context",
            callback = function()
                self.refresh_context_callback()
                UIManager:close(self)
            end,
        }})
    end
    if self.vocabbuilder and self.vocabbuilder.item.last_due_time then
        table.insert(buttons, {{
            text = _("Undo study status"),
            callback = function()
                self.undo_callback()
                UIManager:close(self)
            end
        }})
    end

    local focus_button = ButtonTable:new{
        width = width,
        buttons = buttons,
        show_parent = self
    }

    local copy_button = Button:new{
        text = "", -- copy in nerdfont,
        callback = function()
            Device.input.setClipboardText(self.word)
            UIManager:show(Notification:new{
                text = _("Word copied to clipboard."),
            })
        end,
        bordersize = 0,
    }
    self.book_title_button = Button:new{
        text = self.book_title .. (self.update_callback and '' or book_title_triangle),
        width = width,
        text_font_face = "NotoSans-Italic.ttf",
        text_font_size = 14,
        text_font_bold = false,
        align = self.title_align or "left",
        padding = Size.padding.button,
        bordersize = 0,
        callback = function()
            if self.vocabbuilder then
                self.vocabbuilder:onShowBookAssignment(function(new_book_title)
                    self.book_title = new_book_title
                    self.book_title_button:setText(new_book_title..book_title_triangle, width)
                end)
            end
        end,
        show_parent = self
    }

    table.insert(self.layout, {copy_button})
    if self.vocabbuilder then
        table.insert(self.layout, {self.book_title_button})
    end
    self:mergeLayoutInVertical(focus_button)

    local has_context = self.prev_context or self.next_context
    self[1] = CenterContainer:new{
        dimen = Screen:getSize(),
        MovableContainer:new{
            FrameContainer:new{
                VerticalGroup:new{
                    align = "center",
                    FrameContainer:new{
                        padding = self.padding,
                        padding_top = Size.padding.buttontable,
                        padding_bottom = Size.padding.buttontable,
                        margin = self.margin,
                        bordersize = 0,
                        VerticalGroup:new {
                            align = "left",
                            HorizontalGroup:new{
                                TextWidget:new{
                                    text = self.title,
                                    max_width = width - copy_button:getSize().w - Size.padding.default,
                                    face = word_face,
                                    bold = true,
                                    alignment = self.title_align or "left",
                                },
                                HorizontalSpan:new{ width=Size.padding.default },
                                copy_button,
                            },
                            self.book_title_button,
                            VerticalSpan:new{width= Size.padding.default},
                            has_context and
                            TextBoxWidget:new{
                                text = "..." .. (self.prev_context or ""):gsub("\n", " ") .. "【" ..(self.highlighted_word or self.title).."】" .. (self.next_context or ""):gsub("\n", " ") .. "...",
                                width = width,
                                face = Font:getFace("smallffont"),
                                alignment = self.title_align or "left",
                            }
                            or VerticalSpan:new{ width = Size.padding.default },
                            VerticalSpan:new{ width = has_context and Size.padding.default or 0},
                            TextBoxWidget:new{
                                text = self.dates,
                                width = width,
                                face = Font:getFace("cfont", 14),
                                alignment = self.title_align or "left",
                                fgcolor = dim_color
                            },
                        }

                    },
                    LineWidget:new{
                        background = Blitbuffer.COLOR_GRAY,
                        dimen = Geom:new{
                            w = width + self.padding + self.margin,
                            h = Screen:scaleBySize(1),
                        }
                    },
                    focus_button
                },
                background = Blitbuffer.COLOR_WHITE,
                bordersize = Size.border.window,
                radius = Size.radius.window,
                padding = 0
            }
        }
    }

end

function WordInfoDialog:setTitle(title)
    self.title = title
    self:free()
    self:init()
    UIManager:setDirty("all", "ui")
end

function WordInfoDialog:onShow()
    UIManager:setDirty(self, function()
        return "ui", self[1][1].dimen -- FlipSide-owned word popup: nonflashing update
    end)
end

function WordInfoDialog:onCloseWidget()
    UIManager:setDirty(nil, function()
        return "ui", self[1][1].dimen
    end)
end

function WordInfoDialog:onClose()
    UIManager:close(self)
    if self.tap_close_callback then
        self.tap_close_callback()
    end
    return true
end

function WordInfoDialog:onTap(_, ges)
    if ges.pos:notIntersectWith(self[1][1].dimen) then
        -- Tap outside closes widget
        self:onClose()
        return true
    end
end

function WordInfoDialog:paintTo(...)
    InputContainer.paintTo(self, ...)
    self.dimen = self[1][1].dimen -- FrameContainer
end



-- values useful for item cells
local ellipsis_button_width = Screen:scaleBySize(34)
local star_width = Screen:scaleBySize(25)

local point_widget = TextWidget:new{
    text = " • ",
    bold = true,
    face = Font:getFace("cfont", 24),
    fgcolor = dim_color
}

--[[--
Individual word item widget
--]]--
local VocabItemWidget = InputContainer:extend{
    face = Font:getFace("smallinfofont"),
    width = nil,
    height = nil,
    review_button_width = nil,
    show_parent = nil,
    item = nil,
    forgot_button = nil,
    got_it_button = nil,
    more_button = nil,
    layout = nil
}
--[[--
    item: {
        checked_func: Block,
        review_count: integer,
        word: Text
        book_title: TEXT
        create_time: Integer
        review_time: Integer
        due_time: Integer,
        got_it_callback: function
        remove_callback: function
        is_dim: BOOL
    }
--]]--

local point_widget_height = point_widget:getSize().h
local point_widget_width = point_widget:getSize().w
local word_height = TextWidget:new{text = " ", face = word_face}:getSize().h
local subtitle_height = TextWidget:new{text = " ", face = subtitle_face}:getSize().h


function VocabItemWidget:init()
    self.layout = {}
    self.dimen = Geom:new{w = self.width, h = self.height}
    self.ges_events.Tap = {
        GestureRange:new{
            ges = "tap",
            range = self.dimen,
        }
    }
    self.ges_events.Hold = {
        GestureRange:new{
            ges = "hold",
            range = self.dimen,
        }
    }
    self.v_spacer = VerticalSpan:new{width = math.floor((self.height - word_height - subtitle_height)/2)}
    self.point_v_spacer = VerticalSpan:new{width = (self.v_spacer.width + word_height/2) - point_widget_height/2 }
    self.margin_span = HorizontalSpan:new{ width = Size.padding.large }
    self:initItemWidget()
end

function VocabItemWidget:initItemWidget()
    for i = 1, #self.layout do self.layout[i] = nil end
    if not self.show_parent.is_edit_mode then
        self.more_button = Button:new{
            text = (self.item.prev_context or self.item.next_context) and "⋯" or "⋮",
            padding = Size.padding.button,
            callback = function() self:showMore() end,
            width = ellipsis_button_width,
            bordersize = 0,
            show_parent = self
        }
    else
        self.more_button = IconButton:new{
            icon = "exit",
            width = star_width,
            height = star_width,
            padding = math.floor((ellipsis_button_width - star_width)/2) + Size.padding.button,
            callback = function()
                self:remover()
            end,
        }
    end


    local right_side_width
    local right_widget
    if not self.show_parent.is_edit_mode and self.item.due_time <= os.time() then
        self.has_review_buttons = true
        right_side_width = self.review_button_width * 2 + Size.padding.large * 2 + ellipsis_button_width
        self.forgot_button = Button:new{
            text = _("Forgot"),
            width = self.review_button_width,
            radius = Size.radius.button,
            callback = function()
                self:onForgot()
            end,
            show_parent = self,
        }

        self.got_it_button = Button:new{
            text = _("Got it"),
            radius = Size.radius.button,
            callback = function()
                self:onGotIt()
            end,
            width = self.review_button_width,
            show_parent = self,
        }
        right_widget = HorizontalGroup:new{
            dimen = Geom:new{ w = 0, h = self.height },
            self.margin_span,
            self.forgot_button,
            self.margin_span,
            self.got_it_button,
            self.more_button,
        }
        table.insert(self.layout, self.forgot_button)
        table.insert(self.layout, self.got_it_button)
        table.insert(self.layout, self.more_button)
    else
        self.has_review_buttons = false
        local star = IconWidget:new{
            icon = "check",
            width = star_width,
            height = star_width,
            dim = true
        }

        if self.item.review_count > 6 then
            right_side_width =  Size.padding.large * 4 + 9 * (star:getSize().w)
            right_widget = HorizontalGroup:new {
                dimen = Geom:new{w=0, h = self.height}
            }
            for i=1, 6, 1 do
                table.insert(right_widget, star)
            end
            table.insert(right_widget,
                TextWidget:new {
                    text = " + ",
                    face = word_face,
                    fgcolor = Blitbuffer.COLOR_DARK_GRAY
                }
            )
            table.insert(right_widget, star)
            table.insert(right_widget,
                TextWidget:new {
                    text = "× " .. self.item.review_count-6,
                    face = word_face,
                    fgcolor = Blitbuffer.COLOR_DARK_GRAY
                }
            )
        elseif self.item.review_count > 0 then
            right_side_width =  Size.padding.large * 4 + self.item.review_count * (star:getSize().w)
            right_widget = HorizontalGroup:new {
                dimen = Geom:new{w=0, h = self.height}
            }
            for i=1, self.item.review_count, 1 do
                table.insert(right_widget, star)
            end
        else
            star:free()
            right_side_width =  Size.padding.large * 4
            right_widget = HorizontalGroup:new{
                dimen = Geom:new{w=0, h = self.height},
                 HorizontalSpan:new {width = Size.padding.default }
            }
        end
        table.insert(right_widget, self.margin_span)
        table.insert(right_widget, self.more_button)
        table.insert(self.layout, self.more_button)
    end

    local text_max_width = self.width - point_widget_width - right_side_width

    local subtitle_prefix = TextWidget:new{
        text = self:getTimeSinceDue() .. _("From") .. " ",
        face = subtitle_face,
        fgcolor = subtitle_color
    }

    local word_widget = Button:new{
        text = self.item.word,
        bordersize = 0,
        callback = function() self.item.callback(self.item) end,
        padding = 0,
        max_width = math.ceil(math.max(5,text_max_width - Size.padding.fullscreen))
    }

    word_widget.label_widget.fgcolor = self.item.is_dim and dim_color or Blitbuffer.COLOR_BLACK

    table.insert(self.layout, 1, word_widget)

    self[1] = FrameContainer:new{
        padding = 0,
        bordersize = 0,
        HorizontalGroup:new{
            dimen = Geom:new{
                w = self.width,
                h = self.height,
            },
            HorizontalGroup:new{
                dimen = Geom:new{
                    w = self.width - right_side_width,
                    h = self.height,
                },
                VerticalGroup:new{
                    dimen = Geom:new{w = point_widget_width, h = self.height},
                    self.point_v_spacer,
                    point_widget,
                    VerticalSpan:new { width = self.height - point_widget_height - self.point_v_spacer.width}
                },
                VerticalGroup:new{
                    dimen = Geom:new{
                        w = text_max_width,
                        h = self.height,
                    },
                    self.v_spacer,
                    LeftContainer:new{
                        dimen = Geom:new{w = text_max_width, h = word_height},
                        word_widget
                    },
                    LeftContainer:new{
                        dimen = Geom:new{w = text_max_width, h = math.floor(self.height - word_height - self.v_spacer.width*2.2)},
                        HorizontalGroup:new{
                            subtitle_prefix,
                            TextWidget:new{
                                text = self.item.book_title,
                                face = subtitle_italic_face,
                                max_width = math.ceil(math.max(5,text_max_width - subtitle_prefix:getSize().w - Size.padding.fullscreen)),
                                fgcolor = subtitle_color
                            }
                        }
                    },
                    self.v_spacer
                }

            },
            RightContainer:new{
                dimen = Geom:new{ w = right_side_width+Size.padding.default, h = self.height},
                right_widget
            }
        },
    }
end

function VocabItemWidget:getTimeSinceDue()

    local elapsed = os.time() - self.item.due_time
    local abs = math.abs(elapsed)
    local readable_time

    local rounding = elapsed > 0 and math.floor or math.ceil
    if abs < 60 then
        readable_time = T(C_("Time", "%1s"), abs)
    elseif abs < 3600 then
        readable_time = T(C_("Time", "%1m"), rounding(abs/60))
    elseif abs < 3600 * 24 then
        readable_time = T(C_("Time", "%1h"), rounding(abs/3600))
    elseif abs < 3600 * 24 * 30 then
        readable_time = T(C_("Time", "%1d"), rounding(abs/3600/24))
    elseif abs < 3600 * 24 * 365 then
        readable_time = T(C_("Time", "%1 mo."), rounding(abs/3600/24/3)/10)
    else
        readable_time = T(C_("Time", "%1 yr."), rounding(abs/3600/24/36.5)/10)
    end

    if elapsed < 0 then
        return " " .. readable_time .. " | " --hourglass
    else
        return readable_time .. " | "
    end
end

function VocabItemWidget:remover()
    self.item.remove_callback(self.item)
    self.show_parent:removeAt(self.index)
end

function VocabItemWidget:resetProgress()
    self.item.review_count = 0
    self.item.streak_count = 0
    self.item.due_time = os.time()
    self.item.review_time = self.item.due_time
    self.item.last_due_time = nil
    self.item.is_dim = false
    self:initItemWidget()
    UIManager:setDirty(self.show_parent, function()
        return "ui", self[1].dimen end)
end

function VocabItemWidget:undo()
    self.item.streak_count = self.item.last_streak_count or self.item.streak_count
    self.item.review_count = self.item.last_review_count or self.item.review_count
    self.item.review_time = self.item.last_review_time
    self.item.due_time = self.item.last_due_time or self.item.due_time
    self.item.last_streak_count = nil
    self.item.last_review_count = nil
    self.item.last_review_time = nil
    self.item.last_due_time = nil
    self.item.is_dim = false
    self:initItemWidget()
    UIManager:setDirty(self.show_parent, function()
        return "ui", self[1].dimen end)
end

function VocabItemWidget:removeAndClose()
    self:remover()
    UIManager:close(self.dialogue)
end

function VocabItemWidget:showMore()
    -- @translators Used in vocabbuilder: %1 date
    local date_str = T(_("Added on %1"), os.date("%Y-%m-%d", self.item.create_time))
    -- @translators Used in vocabbuilder: %1 time
    local time_str = T(_("Review scheduled at %1"), os.date("%Y-%m-%d %H:%M", self.item.due_time))
    local dialogue = WordInfoDialog:new{
        title = self.item.word,
        highlighted_word = self.item.highlight,
        book_title = self.item.book_title,
        dates = date_str .. " | " .. time_str,
        prev_context = self.item.prev_context,
        next_context = self.item.next_context,
        remove_callback = function()
            self:remover()
        end,
        reset_callback = function()
            self:resetProgress()
        end,
        undo_callback = function()
            self:undo()
        end,
        vocabbuilder = self
    }

    UIManager:show(dialogue)
end

function VocabItemWidget:onTap(_, ges)
    if self.has_review_buttons then
        if ges.pos.x > self.forgot_button.dimen.x and ges.pos.x < self.forgot_button.dimen.x + self.forgot_button.dimen.w then
            self:onForgot()
        elseif ges.pos.x > self.got_it_button.dimen.x and ges.pos.x < self.got_it_button.dimen.x + self.got_it_button.dimen.w then
            self:onGotIt()
        elseif ges.pos.x > self.more_button.dimen.x and ges.pos.x < self.more_button.dimen.x + self.more_button.dimen.w then
            self:showMore()
        elseif self.item.callback then
            self.item.callback(self.item)
        end
    else
        if BD.mirroredUILayout() then
            if ges.pos.x > self.more_button.dimen.x and ges.pos.x < self.more_button.dimen.x + self.more_button.dimen.w * 2 then
                if self.show_parent.is_edit_mode then
                    self:remover()
                else
                    self:showMore()
                end
            elseif self.item.callback then
                self.item.callback(self.item)
            end
        else
            if ges.pos.x > self.more_button.dimen.x - self.more_button.dimen.w and ges.pos.x < self.more_button.dimen.x + self.more_button.dimen.w then
                if self.show_parent.is_edit_mode then
                    self:remover()
                else
                    self:showMore()
                end
            elseif self.item.callback then
                self.item.callback(self.item)
            end
        end
    end
    return true
end

function VocabItemWidget:onHold(_, ges)
    self:onShowBookAssignment()
    return true
end

function VocabItemWidget:onGotIt()
    self.item.got_it_callback(self.item)
    self.item.is_dim = true
    self:initItemWidget()
    if self.show_parent.selected.x == 3 then
        self.show_parent.selected.x = 1
    end
    UIManager:setDirty(self.show_parent, function()
    return "ui", self[1].dimen end)
end

function VocabItemWidget:onForgot(no_lookup)
    self.item.forgot_callback(self.item)
    self.item.is_dim = false
    self:initItemWidget()
    UIManager:setDirty(self.show_parent, function()
        return "ui", self[1].dimen end)
    if not no_lookup and  self.item.callback then
        self.item.callback(self.item)
    end
end


function VocabItemWidget:onShowBookAssignment(title_changed_cb)
    local sort_items = {}
    local book_data = DB:selectBooks()
    local sort_widget
    local book = self.item.book_title
    local id
    for _, info in pairs(book_data) do
        table.insert(sort_items, {
            text = info.name or "",
            callback = function()
                id = info.id
                book = info.name
            end,
            checked_func = function()
                return info.name == book
            end,
            hold_callback = function(sort_item, onSuccess)
                local book_title = self.item.book_title
                self.show_parent:showChangeBookTitleDialog(sort_item, function()
                    onSuccess()
                    if book_title == info.name then
                        if book == book_title then
                            book = sort_item.text
                        end
                        info.name = sort_item.text
                        if title_changed_cb then title_changed_cb(sort_item.text) end
                    end
                end)
            end
        })
    end
    table.insert(sort_items, {
        text = _("Add virtual book"),
        face = Font:getFace("smallinfofontbold"),
        callback = function()
            local dialog
            dialog = InputDialog:new{
                title = _("Enter book title:"),
                input = "",
                buttons = {
                    {
                        {
                            text = _("Cancel"),
                            id = "close",
                            callback = function()
                                UIManager:close(dialog)
                            end,
                        },
                        {
                            text = _("Add"),
                            is_enter_default = true,
                            callback = function()
                                if dialog:getInputText() == "" then return end
                                local new_book_title = dialog:getInputText()
                                local ok, new_id = pcall(DB.insertNewBook, DB, new_book_title)
                                if ok then
                                    UIManager:close(dialog)
                                    table.insert(sort_items, #sort_items, {
                                        text = new_book_title,
                                        callback = function()
                                            id = new_id
                                            book = new_book_title
                                        end,
                                        checked_func = function()
                                            return new_book_title == book
                                        end,
                                        hold_callback = function(sort_item, onSuccess)
                                            self.show_parent:showChangeBookTitleDialog(sort_item, onSuccess)
                                        end
                                    })
                                    sort_widget:onGoToPage(sort_widget.show_page)
                                else
                                    UIManager:show(require("ui/widget/notification"):new{
                                        text = _("Book title already in use."),
                                        timeout = 3
                                    })
                                end
                            end,
                        },
                    }
                },
            }
            UIManager:show(dialog)
            dialog:onShowKeyboard()
        end
    })

    sort_widget = SortWidget:new{
        title = T(_("Move \"%1\" to book:"), self.item.word),
        item_table = sort_items,
        sort_disabled = true,
        callback = function()
            if book ~= self.item.book_title then
                self.item.book_title = book
                DB:updateBookIdOfWord(self.item.word, id)
                self:initItemWidget()
                if title_changed_cb then title_changed_cb(book) end
            end
            UIManager:setDirty(nil, "ui")
        end
    }
    UIManager:show(sort_widget)
end

--[[--
Container widget. Same as sortwidget
--]]--
local VocabularyBuilderWidget = FocusManager:extend{
    title = "",
    width = nil,
    height = nil,
    -- index for the first item to show
    show_page = 1,
    -- table of items
    item_table = nil, -- mandatory (array)
    is_edit_mode = false,
    callback = nil,
}

function VocabularyBuilderWidget:init()
    self.item_table = self:getVocabItems()
    self.layout = {}

    self.dimen = Geom:new{
        w = self.width or Screen:getWidth(),
        h = self.height or Screen:getHeight(),
    }

    if Device:hasKeys() then
        self.key_events.Close = { { Device.input.group.Back } }
        self.key_events.NextPage = { { Device.input.group.PgFwd } }
        self.key_events.PrevPage = { { Device.input.group.PgBack } }
        self.key_events.ShowMenu = { { "Menu" }}
    end
    if Device:isTouchDevice() then
        self.ges_events.Swipe = {
            GestureRange:new{
                ges = "swipe",
                range = self.dimen,
            }
        }
        self.ges_events.MultiSwipe = {
            GestureRange:new{
                ges = "multiswipe",
                range = function() return self.dimen end,
            }
        }
    end
    self.page_info = HorizontalGroup:new{}
    self:refreshFooter()

    local bottom_line = LineWidget:new{
        dimen = Geom:new{ w = self.item_width, h = Size.line.thick },
        background = Blitbuffer.COLOR_LIGHT_GRAY,
    }
    local vertical_footer = VerticalGroup:new{
        bottom_line,
        self.page_info,
    }
    self.footer_height = vertical_footer:getSize().h
    local footer = BottomContainer:new{
        dimen = self.dimen:copy(),
        vertical_footer,
    }
    -- setup title bar
    self.title_bar = TitleBar:new{
        width = self.dimen.w,
        align = "center",
        title_face = Font:getFace("smallinfofontbold"),
        bottom_line_color = Blitbuffer.COLOR_LIGHT_GRAY,
        with_bottom_line = true,
        bottom_line_h_padding = Size.padding.large,
        left_icon = "appbar.menu",
        left_icon_tap_callback = function() self:onShowMenu() end,
        title = self.title,
        close_callback = function() self:onClose() end,
        show_parent = self,
    }

    self:setupItemHeight()
    self.main_content = VerticalGroup:new{}

    -- calculate item's review button width once
    local temp_button = Button:new{
        text = _("Got it"),
        padding_h = Size.padding.large
    }
    self.review_button_width = temp_button:getSize().w
    temp_button:setText(_("Forgot"))
    self.review_button_width = math.min(math.max(self.review_button_width, temp_button:getSize().w), Screen:getWidth()/4)
    temp_button:free()

    self:_populateItems()

    local frame_content = FrameContainer:new{
        height = self.dimen.h,
        padding = 0,
        bordersize = 0,
        background = Blitbuffer.COLOR_WHITE,
        VerticalGroup:new{
            self.title_bar,
            self.main_content,
        },
    }
    local content = OverlapGroup:new{
        dimen = self.dimen:copy(),
        frame_content,
        footer,
    }
    -- assemble page
    self[1] = FrameContainer:new{
        height = self.dimen.h,
        padding = 0,
        bordersize = 0,
        background = Blitbuffer.COLOR_WHITE,
        content
    }
    self.vocabbuilder[1] = self
end

function VocabularyBuilderWidget:refreshFooter()
    local has_sync = settings.server ~= nil
    local has_search = self.search_text_sql
    if self.footer_left ~= nil then -- check whether refresh needed
        local should_refresh = has_sync and self.page_info[1] ~= self.footer_sync
                               or not has_sync and self.page_info[1] == self.footer_sync
        if not should_refresh then
            should_refresh = has_search and self.page_info[#self.page_info] ~= self.footer_search
                             or not has_search and self.page_info[#self.page_info] == self.footer_search
        end
        if not should_refresh then return end
    end

    self.page_info:clear()
    local padding = Size.padding.large
    self.width_widget = self.dimen.w - 2 * padding
    self.item_width = self.dimen.w - 2 * padding
    self.footer_center_width = math.floor(self.width_widget * (32/100))
    self.footer_button_width = math.floor(self.width_widget * (12/100))
    local left_ratio = 10
    local right_ratio = 10
    if has_sync and not has_search then
        left_ratio = 9
        right_ratio = 11
    end
    self.footer_left_corner_width = math.floor(self.width_widget * left_ratio/100)
    self.footer_right_corner_width = math.floor(self.width_widget * right_ratio/100)
    -- group for footer
    local chevron_left = "chevron.left"
    local chevron_right = "chevron.right"
    local chevron_first = "chevron.first"
    local chevron_last = "chevron.last"
    if BD.mirroredUILayout() then
        chevron_left, chevron_right = chevron_right, chevron_left
        chevron_first, chevron_last = chevron_last, chevron_first
    end
    self.footer_left = Button:new{
        icon = chevron_left,
        width = self.footer_button_width,
        callback = function() self:prevPage() end,
        bordersize = 0,
        radius = 0,
        show_parent = self,
    }
    self.footer_right = Button:new{
        icon = chevron_right,
        width = self.footer_button_width,
        callback = function() self:nextPage() end,
        bordersize = 0,
        radius = 0,
        show_parent = self,
    }
    self.footer_first_up = Button:new{
        icon = chevron_first,
        width = self.footer_button_width,
        callback = function()
            self:goToPage(1)
        end,
        bordersize = 0,
        radius = 0,
        show_parent = self,
    }
    self.footer_last_down = Button:new{
        icon = chevron_last,
        width = self.footer_button_width,
        callback = function()
            self:goToPage(self.pages)
        end,
        bordersize = 0,
        radius = 0,
        show_parent = self,
    }
    local footer_height = self.footer_last_down:getSize().h
    local sync_size = TextWidget:getFontSizeToFitHeight("cfont", footer_height, Size.padding.buttontable*2)
    self.footer_sync = Button:new{
        text = "⇅",
        width = self.footer_left_corner_width,
        text_font_size = sync_size,
        text_font_bold = false,
        bordersize = 0,
        radius = 0,
        padding_h = Size.padding.large,
        padding_v = Size.padding.button,
        margin = 0,
        show_parent = self,
        callback = function()
            self.vocabbuilder:onSyncFlipSideDB()
        end
    }
    self.footer_sync.label_widget.fgcolor = Blitbuffer.COLOR_GRAY_3

    self.footer_search = Button:new{
        icon = "appbar.search",
        width = self.footer_right_corner_width,
        icon_width = math.floor(footer_height - Size.padding.large),
        icon_height = math.floor(footer_height - Size.padding.large),
        callback = function()
            self:showSearchDialog()
        end,
        bordersize = 0,
        radius = 0,
        show_parent = self,
    }
    self.footer_page = Button:new{
        text = "",
        hold_input = {
            title = _("Enter page number"),
            input_type = "number",
            hint_func = function()
                return string.format("(1 - %s)", self.pages)
            end,
            callback = function(input)
                local page = tonumber(input)
                if page and page >= 1 and page <= self.pages then
                    self:goToPage(page)
                end
            end,
            ok_text = _("Go to page"),
        },
        call_hold_input_on_tap = true,
        bordersize = 0,
        margin = 0,
        text_font_face = "pgfont",
        text_font_bold = false,
        width = self.footer_center_width,
        show_parent = self,
    }
    table.insert(self.page_info, has_sync and self.footer_sync or HorizontalSpan:new{width=self.footer_left_corner_width})
    table.insert(self.page_info, self.footer_first_up)
    table.insert(self.page_info, self.footer_left)
    table.insert(self.page_info, self.footer_page)
    table.insert(self.page_info, self.footer_right)
    table.insert(self.page_info, self.footer_last_down)
    table.insert(self.page_info, has_search and self.footer_search or HorizontalSpan:new{ width = self.footer_right_corner_width })
end

function VocabularyBuilderWidget:showSearchDialog()
    local dialog
    dialog = InputDialog:new{
        title = _("Search words"),
        input = self.search_text or "",
        input_hint = _("Search empty content to exit"),
        buttons = {
            {
                {
                    text = _("Cancel"),
                    id = "close",
                    callback = function()
                        UIManager:close(dialog)
                    end,
                },
                {
                    text = _("Info"),
                    callback = function()
                        local text_info = _([[You can use two wildcards when searching: the percent sign (%) and the underscore (_).
% represents any zero or more number of characters and _ represents any single character.

If no wildcard is used, the searched text will be enclosed with two %'s by default.]])
                        UIManager:show(InfoMessage:new{ text = text_info })
                    end,
                },
                {
                    text = _("Search"),
                    is_enter_default = true,
                    callback = function()
                        self.search_text = dialog:getInputText()
                        if self.search_text == "" then
                            self.search_text_sql = nil
                        elseif self.search_text:find("%", 1, true) or self.search_text:find("_") then
                            self.search_text_sql = self.search_text:gsub("'", "''")
                        else
                            self.search_text_sql = "%" .. self.search_text:gsub("'", "''") .. "%"
                        end
                        UIManager:close(dialog)
                        self:reloadItems()
                    end,
                },
            }
        },
    }
    UIManager:show(dialog)
    dialog:onShowKeyboard()
end

function VocabularyBuilderWidget:setupItemHeight()
    local item_height = Screen:scaleBySize(self.is_edit_mode and 54 or 72)
    self.item_height = item_height
    self.item_margin = math.floor(self.item_height / 8)
    local line_height = self.item_height + self.item_margin
    local content_height = self.dimen.h - self.title_bar:getHeight() - self.footer_height - Size.padding.large
    self.items_per_page = math.floor(content_height / line_height)
    self.item_margin = self.item_margin + math.floor((content_height - self.items_per_page * line_height ) / self.items_per_page )
    self.pages = math.ceil(#self.item_table / self.items_per_page)
    self.show_page = math.max(1, math.min(self.pages, self.show_page))
end

function VocabularyBuilderWidget:nextPage()
    local new_page = self.show_page == self.pages and 1 or self.show_page + 1
    self.show_page = new_page
    self:_populateItems()
end

function VocabularyBuilderWidget:prevPage()
    local new_page = self.show_page == 1 and self.pages or self.show_page - 1
    self.show_page = new_page
    self:_populateItems()
end

function VocabularyBuilderWidget:goToPage(page)
    self.show_page = page
    self:_populateItems()
end

function VocabularyBuilderWidget:moveItem(diff)
    local move_to = diff
    if move_to > 0 and move_to <= #self.item_table then
        self.show_page = math.ceil(move_to / self.items_per_page)
        self:_populateItems()
    end
end

function VocabularyBuilderWidget:removeAt(index)
    if index > #self.item_table then return end
    table.remove(self.item_table, index)
    self.show_page = math.ceil(math.min(index, #self.item_table) / self.items_per_page)
    self.pages = math.ceil(#self.item_table / self.items_per_page)
    self:_populateItems()
end

-- make sure self.item_margin and self.item_height are set before calling this
function VocabularyBuilderWidget:_populateItems()
    self.main_content:clear()
    self.layout = {{self.title_bar.left_button, self.title_bar.right_button}} -- title
    local idx_offset = (self.show_page - 1) * self.items_per_page
    local page_last
    if idx_offset + self.items_per_page <= #self.item_table then
        page_last = idx_offset + self.items_per_page
    else
        page_last = #self.item_table
    end

    self:selectVocabItems(idx_offset, page_last)

    for idx = idx_offset + 1, page_last do
        table.insert(self.main_content, VerticalSpan:new{ width = self.item_margin / (idx == idx_offset+1 and 2 or 1) })
        if #self.item_table == 0 or not self.item_table[idx].word then break end
        local item = VocabItemWidget:new{
            height = self.item_height,
            width = self.item_width,
            review_button_width = self.review_button_width,
            item = self.item_table[idx],
            index = idx,
            show_parent = self,
        }
        table.insert(self.layout, #self.layout, item.layout)
        table.insert(
            self.main_content,
            item
        )
    end
    self:refreshFooter()
    if settings.server then
        table.insert(self.layout, #self.layout, {self.footer_sync})
    end
    if #self.main_content == 0 then
        table.insert(self.main_content, HorizontalSpan:new{width = self.item_width})
    end
    self.footer_page:setText(T(_("Page %1 of %2"), self.show_page, self.pages), self.footer_center_width)
    if self.pages > 1 then
        self.footer_page:enable()
    else
        self.footer_page:disableWithoutDimming()
    end
    if self.pages == 0 then
        local text
        if self.search_text_sql then
            text = _("Search in effect")
        else
            local has_filtered_book = DB:hasFilteredBook()
            text = has_filtered_book and _("Filter in effect") or
                self:check_reverse() and _("No reviewable items") or _("No items")
        end
        self.footer_page:setText(text, self.footer_center_width)
        self.footer_first_up:hide()
        self.footer_last_down:hide()
        self.footer_left:hide()
        self.footer_right:hide()
    elseif self.footer_left.hidden then
        self.footer_first_up:show()
        self.footer_last_down:show()
        self.footer_left:show()
        self.footer_right:show()
    end
    local chevron_first = "chevron.first"
    local chevron_last = "chevron.last"
    if BD.mirroredUILayout() then
        chevron_first, chevron_last = chevron_last, chevron_first
    end

    self.footer_first_up:setIcon(chevron_first, self.footer_button_width)
    self.footer_last_down:setIcon(chevron_last, self.footer_button_width)
    self.footer_left:enableDisable(self.show_page > 1)
    self.footer_right:enableDisable(self.show_page < self.pages)
    self.footer_first_up:enableDisable(self.show_page > 1)
    self.footer_last_down:enableDisable(self.show_page < self.pages)
    if not self.layout[self.selected.y] or not self.layout[self.selected.y][self.selected.x] then
        self.selected = {x=1, y=1}
    end
    UIManager:setDirty(self, function()
        return "ui", self.dimen
    end)
end

function VocabularyBuilderWidget:gotItFromDict(word)
    for vocabItem in self:vocabItemIter() do
        if vocabItem.item.word == word then
            vocabItem:onGotIt()
            return
        end
    end
end

function VocabularyBuilderWidget:forgotFromDict(word)
    for vocabItem in self:vocabItemIter() do
        if vocabItem.item.word == word then
            vocabItem:onForgot(true)
            return
        end
    end
end

function VocabularyBuilderWidget:resetItems()
    for i, item in ipairs(self.item_table) do
        if self.item_table[i].word then -- selected from DB
            self.item_table[i] = {
                callback = self.item_table[i].callback
            }
        end
    end
    self.reload_time = os.time()
    self:_populateItems()
end

function VocabularyBuilderWidget:onShowMenu()
    local menu = MenuDialog:new{
        is_edit_mode = self.is_edit_mode,
        edit_callback = function()
            self.is_edit_mode = not self.is_edit_mode
            self:setupItemHeight()
            self:_populateItems()
        end,
        clean_callback = function()
            self.item_table = {}
            self.pages = 0
            self:_populateItems()
        end,
        reset_callback = function()
            self:resetItems()
        end,
        vocabbuilder = self
    }

    menu:setupPluginMenu()
    UIManager:show(menu)
end

function VocabularyBuilderWidget:check_reverse()
    return settings.reverse
end


function VocabularyBuilderWidget:onShowFilter()
    local sort_items = {}
    local book_data = DB:selectBooks()
    local toggled = {}
    local sort_widget
    for _, info in pairs(book_data) do
        table.insert(sort_items, {
            text = info.name or "",
            callback = function()
                info.filter = not info.filter
                if toggled[info.id] then
                    toggled[info.id] = nil
                else
                    toggled[info.id] = true
                end
            end,
            checked_func = function()
                return info.filter
            end,
            hold_callback = function(sort_item, onSuccess)
                local menu = MenuDialog:new{
                    show_parent = sort_widget
                }
                menu:setupBookMenu(sort_item, onSuccess)
                UIManager:show(menu)
            end,
        })
    end

    sort_widget = SortWidget:new{
        title = _("Filter words from books"),
        item_table = sort_items,
        sort_disabled = true,
        callback = function()
            if #toggled then
                DB:toggleBookFilter(toggled)
                self:reloadItems()
            end

            UIManager:setDirty(nil, "ui")
        end,
        show_parent = self
    }

    if Device:hasKeys() then
        sort_widget.key_events.ShowMenu = { { "Menu" }}
        sort_widget.onShowMenu = function(this)
            local item = this:getFocusItem()
            if item and item.onHold then
                item:onHold()
            end
        end
    end

    UIManager:show(sort_widget)
end

function VocabularyBuilderWidget:showChangeBookTitleDialog(sort_item, onSuccess)
    local dialog
    dialog = InputDialog:new {
        title = _("Change book title to:"),
        input = sort_item.text,
        buttons = {
            {
                {
                    text = _("Cancel"),
                    id = "close",
                    callback = function()
                        UIManager:close(dialog)
                    end,
                },
                {
                    text = _("Change title"),
                    is_enter_default = true,
                    callback = function()
                        if dialog:getInputText() == "" then return end
                        local new_book_title = dialog:getInputText()
                        local ok = pcall(DB.changeBookTitle, DB, sort_item.text, new_book_title)
                        if ok then
                            for i=1, #self.item_table do
                                if self.item_table[i].book_title == sort_item.text then
                                    self.item_table[i].book_title = new_book_title
                                end
                            end
                            sort_item.text = new_book_title
                            UIManager:close(dialog)
                            if onSuccess then onSuccess() end
                            self:_populateItems()
                        else
                            UIManager:show(require("ui/widget/notification"):new {
                                text = _("Book title already in use."),
                                timeout = 3
                            })
                        end
                    end,
                },
            }
        },
    }
    UIManager:show(dialog)
    dialog:onShowKeyboard()
end

function VocabularyBuilderWidget:reloadItems()
    DB:batchUpdateItems(self.item_table)
    self.item_table = self:getVocabItems()
    self.pages = math.ceil(#self.item_table / self.items_per_page)
    self:goToPage(1)
end

function VocabularyBuilderWidget:onShow()
    UIManager:setDirty(self, "ui")
end

function VocabularyBuilderWidget:onNextPage()
    self:nextPage()
    return true
end

function VocabularyBuilderWidget:onPrevPage()
    self:prevPage()
    return true
end

function VocabularyBuilderWidget:onSwipe(arg, ges_ev)
    local direction = BD.flipDirectionIfMirroredUILayout(ges_ev.direction)
    if direction == "west" then
        self:onNextPage()
    elseif direction == "east" then
        self:onPrevPage()
    elseif direction == "south" then
        -- Allow easier closing with swipe down
        self:onClose()
    elseif direction == "north" then
        -- open filter
        self:onShowFilter()
    else -- diagonal swipe
        -- Legacy list gesture must not initiate an extra e-ink full refresh.
        -- The single manual refresh gesture lives in Flashcards:onSwipeCards.
        return true
    end
end

function VocabularyBuilderWidget:onMultiSwipe(arg, ges_ev)
    -- if user is drawing a circle or half circle (full circle not always easy), reload
    local space_count = 0
    for space in ges_ev.multiswipe_directions:gmatch(" ") do
        space_count = space_count + 1
        if space_count == 2 then break end
    end
    if space_count == 2 and (
        string.find("east south west north east south west", ges_ev.multiswipe_directions)
        or string.find("east north west south east north west", ges_ev.multiswipe_directions)
    ) then
        self:reloadItems()
        UIManager:show(Notification:new{ text = _("Words reloaded") })
    else
        -- For consistency with other fullscreen widgets where swipe south can't be
        -- used to close and where we then allow any multiswipe to close, allow any
        -- multiswipe to close this widget too.
        self:onClose()
    end
    return true
end

function VocabularyBuilderWidget:onClose()
    DB:batchUpdateItems(self.item_table)
    UIManager:close(self)
    self.vocabbuilder.widget = nil
    self.vocabbuilder[1] = nil
    -- UIManager:setDirty(self, "ui")
end

function VocabularyBuilderWidget:onCancel()
    self:goToPage(self.show_page)
    return true
end

function VocabularyBuilderWidget:onReturn()
    return self:onClose()
end

-- This skips the VerticalSpan widgets which are also in self.main_content
function VocabularyBuilderWidget:vocabItemIter()
    local i, n = 0, #self.main_content
    return function()
        while true do
            i = i + 1
            if i > n then return nil end
            if self.main_content[i].item then
                return self.main_content[i]
            end
        end
    end
end

function VocabularyBuilderWidget:getVocabItems()
    self.reload_time = os.time()
    local vocab_items = {}
    for _ = 1, DB:selectCount(self) do
        table.insert(vocab_items, {
            callback = function(item)
                self.current_lookup_word = item.word
                self.ui:handleEvent(Event:new("LookupWord", item.word, true, nil, nil, nil))
            end
        })
    end
    return vocab_items
end

function VocabularyBuilderWidget:selectVocabItems(start_idx, end_idx)
    DB:select_items(self, start_idx, end_idx)
end

--[[--
Item shown in main menu
--]]--
function VocabBuilder:init()
    self.ui.menu:registerToMainMenu(self)
    self:registerDictButtons()
    -- Capture original reading text at the start of each dictionary lookup,
    -- before KOReader may clear its selection. This affects FlipSide only.
    local sentence = package.loaded["flipside_full_sentence_shared"]
    if sentence and sentence.installLookupCapture then
        sentence.installLookupCapture(self, function() return settings.with_context == true end)
    end
    -- Register Save meaning before a dictionary lookup is created. This
    -- leaves DictQuickLookup's initialization and KOReader event path intact.
    local ok, saved = pcall(require, 'flipside_saved_meanings')
    if ok and saved and saved.registerDictionaryButton and self.ui then
        saved.registerDictionaryButton(self.ui.dictionary)
    end
    self:onDispatcherRegisterActions()
end

function VocabBuilder:addToMainMenu(menu_items)
    menu_items.flipside = {
        text = "FlipSide",
        -- Explicitly attach FlipSide to the search (magnifying-glass) tab.
        -- Applies in both Reader and File Manager. Without sorting_hint,
        -- KOReader puts unknown items into the first tab as "NEW: ...".
        sorting_hint = "search",
        callback = function()
            self:onShowFlipSide()
        end
    }
end

function VocabBuilder:registerDictButtons()
    if not self.ui or not self.ui.dictionary then return end
    self.ui.dictionary:addToDictButtons({
        id = "flipside",
        menu_text = "FlipSide",
        text = "Add to FlipSide",
        insert_first = true,
        font_bold = false,
        auto_row_style_width_min_row_size = 2,
        auto_row_style_width_ratio = 0.7,
        show_func = function(dict_popup)
            -- Bind the source selection to this specific popup when it is
            -- built; it stays valid even if another dictionary opens later.
            local sentence = package.loaded["flipside_full_sentence_shared"]
            local snapshot = self._flipside_pending_context
            if not dict_popup._flipside_context_snapshot and sentence
                and sentence.snapshotMatches
                and sentence.snapshotMatches(snapshot, dict_popup.word,
                    dict_popup.highlight) then
                dict_popup._flipside_context_snapshot = snapshot
            end
            if settings.enabled then
                -- words are added automatically, no need to add the button.
                return false
            end
            if self.widget and self.widget.current_lookup_word == dict_popup.word then
                -- We are calling from within the vocab builder, and the word is already
                -- added to vocab builder, no need to add the button for review.
                return false
            end
            return true
        end,
        callback = function(dict_popup)
            local button = dict_popup.button_table.button_by_id["flipside"]
            if not button then return end

            local is_adding = dict_popup._flipside_action_state
            if is_adding == nil then
                is_adding = true
            end

            if is_adding then
                local book_title = (dict_popup.ui.doc_props and dict_popup.ui.doc_props.display_title) or _("Dictionary lookup")
                -- NEVER broadcast WordLookedUp here: the native Vocabulary
                -- Builder consumes that event too and would add this word to
                -- its own database. Call only FlipSide's private handler.
                -- Support KOReader HandlerSandbox's callable .f wrapper.
                local handler = self.onWordLookedUp
                if type(handler) == "table" then handler = handler.f end
                flipSideManualLookup = true
                local ok, result = pcall(function()
                    assert(type(handler) == "function", "FlipSide lookup handler unavailable")
                    local sentence = package.loaded["flipside_full_sentence_shared"]
                    local capture = dict_popup._flipside_context_snapshot
                    if not capture and sentence and sentence.snapshotMatches then
                        local pending = self._flipside_pending_context
                        if sentence.snapshotMatches(pending, dict_popup.word,
                                dict_popup.highlight) then
                            capture = pending
                        end
                    end
                    if not capture and sentence and sentence.captureAtLookup then
                        -- Last chance if the popup was built by another path.
                        local ok_capture, fallback = pcall(sentence.captureAtLookup,
                            dict_popup.highlight, dict_popup.word)
                        if ok_capture then capture = fallback end
                    end
                    return handler(self, dict_popup.lookupword, book_title, true, capture)
                end)
                flipSideManualLookup = false -- always restore, even on failure
                if not ok or result == false then
                    UIManager:show(InfoMessage:new{
                        text = "FlipSide could not add this word: " .. tostring(result),
                    })
                    return
                end
                -- Recover earlier Save records made under the selected form.
                -- Keep SRS, context and dictionary behavior completely intact.
                if saved and saved.copyFromSelectedForm then
                    local linked,linkerr=pcall(saved.copyFromSelectedForm,
                        dict_popup.lookupword,dict_popup.word)
                    if not linked then
                        logger.warn('FlipSide meaning recovery on add failed:',linkerr)
                    end
                end
                dict_popup._flipside_action_state = false
                button:setText(_("Remove from FlipSide"), button.width)
                UIManager:setDirty(dict_popup, function()
                    return "ui", button.dimen
                end)
            else
                UIManager:show(ConfirmBox:new{
                    text = T(_("Remove word \"%1\" from FlipSide?"), dict_popup.lookupword),
                    ok_text = _("Remove"),
                    ok_callback = function()
                        dict_popup._flipside_action_state = true
                        DB:remove({word = dict_popup.lookupword})
                        button:setText(_("Add to FlipSide"), button.width)
                        UIManager:setDirty(dict_popup, function()
                            return "ui", button.dimen
                        end)
                    end
                })
            end
        end,
    })
    local function getCurrentVocabItem(dict_popup)
        if not self.widget then
            return nil
        end
        for vocabItem in self.widget:vocabItemIter() do
            if vocabItem.item and vocabItem.item.word == dict_popup.word then
                return vocabItem.item
            end
        end
        return nil
    end
    self.ui.dictionary:addToDictButtons({
        id = "flipside_forgot",
        text = _("Forgot"),
        conditional = true,
        row_group = "vocab_review",
        show_func = function(dict_popup)
            local item = getCurrentVocabItem(dict_popup)
            return item ~= nil and item.due_time <= os.time()
        end,
        callback = function(dict_popup)
            local item = getCurrentVocabItem(dict_popup)
            if not item or not self.widget then return end
            self.widget:forgotFromDict(item.word)
            dict_popup:onClose()
        end,
    })
    self.ui.dictionary:addToDictButtons({
        id = "flipside_got_it",
        text = _("Got it"),
        conditional = true,
        row_group = "vocab_review",
        show_func = function(dict_popup)
            local item = getCurrentVocabItem(dict_popup)
            return item ~= nil and item.due_time <= os.time()
        end,
        callback = function(dict_popup)
            local item = getCurrentVocabItem(dict_popup)
            if not item or not self.widget then return end
            self.widget:gotItFromDict(item.word)
            dict_popup:onClose()
        end,
    })
end

function VocabBuilder:onDispatcherRegisterActions()
    Dispatcher:registerAction("show_flipside",
        {category="none", event="ShowFlipSide", title="Open FlipSide", general=true})
    Dispatcher:registerAction("sync_flipside_all",
        {category="none", event="SyncFlipSideAll", title="Sync all", general=true})
end

function VocabBuilder:onShowFlipSide()
    self.widget = VocabularyBuilderWidget:new{
        title = "FlipSide",
        vocabbuilder = self,
        ui = self.ui
    }
    UIManager:show(self.widget)
    -- Show only when Learning Analysis could not load or attach completely.
    -- Never let a review session quietly appear to have saved its statistics.
    if self._flipside_audit_load_failed then
        UIManager:show(InfoMessage:new{
            text = "Learning Analysis could not initialize completely. Reviews may not be recorded in statistics. Check crash.log before continuing reviews.",
            timeout = 8,
        })
    end
    return true
end

-- The footer uses FlipSide's own card-sync stage, not KOReader's legacy
-- Vocabulary Builder Cloud:sync event/remote filename.
function VocabBuilder:onSyncFlipSideDB()
    return require("flipside_sync").start(self, "cards")
end

-- Explicit private API for FlipSide's integrated Learning Analysis.
-- Do not recover the DB/Widget by introspecting any sync/show function:
-- refactoring those functions must never silently disable statistics hooks.
-- Return the existing FlipSide classes as well, so Learning Analysis never
-- has to locate them through Lua closure upvalues. The first two results
-- remain unchanged for callers expecting the original interface.
-- This does not instantiate databases or change reviews or saved records.
function VocabBuilder:getFlipSideAuditInternals()
    return DB, VocabularyBuilderWidget, VocabItemWidget, MenuDialog
end

-- Independent gesture actions and the Cloud sync menu continue using
-- FlipSide's serialized coordinator and existing server settings.
function VocabBuilder:getFlipSideSyncServer()
    return settings.server
end

function VocabBuilder:prepareFlipSideSync()
    if self.widget and self.widget.item_table then
        DB:batchUpdateItems(self.widget.item_table)
    end
end

function VocabBuilder:onSyncFlipSideAll()
    return require("flipside_sync").start(self, "all")
end

-- CRAM uses its own optional cloud folder, separate from card storage.
-- The KOReader Cloud Storage chooser provides an account reference.
function VocabBuilder:getFlipSideCramSyncServer()
    return G_reader_settings:readSetting("flipside_cram_cloud_folder")
end

function VocabBuilder:setFlipSideCramSyncServer(server)
    if type(server) ~= "table" or type(server.type) ~= "string"
            or type(server.url) ~= "string" then return false end
    G_reader_settings:saveSetting("flipside_cram_cloud_folder", server)
    G_reader_settings:flush()
    return true
end

function VocabBuilder:setFlipSideSyncServer(server)
    if type(server) ~= "table" or type(server.type) ~= "string"
            or type(server.url) ~= "string" then return false end
    local previous = settings.server
    settings.server = server
    G_reader_settings:saveSetting(VocabBuilder.settings_key, settings)
    G_reader_settings:flush()
    if previous and (previous.type ~= server.type
            or previous.url ~= server.url or previous.address ~= server.address) then
        -- A new remote server must not reuse the old 3-way merge baseline.
        os.remove(DB.path .. ".sync")
    end
    return true
end

-- WordLookedUp is a shared KOReader event. Native manual additions go
-- exclusively to KOReader's official Vocabulary Builder; our own button
-- bypasses the event dispatcher and sets flipSideManualLookup explicitly.
-- Automatic dictionary lookups are independent and still obey FlipSide's
-- own Auto add new words setting.
function VocabBuilder:onWordLookedUp(word, title, is_manual, explicit_capture)
    if is_manual and not flipSideManualLookup then return false end
    if not settings.enabled and not is_manual then return end
    if self.widget and self.widget.current_lookup_word == word then return true end
    local prev_context
    local next_context
    local highlight
    if settings.with_context then
        local sentence = package.loaded["flipside_full_sentence_shared"]
        local capture = explicit_capture
        -- Automatic adds run during KOReader's lookup event, immediately
        -- after our dictionary hook captured its original selection.
        if not capture and not is_manual and sentence
            and sentence.snapshotMatches
            and sentence.snapshotMatches(self._flipside_pending_context, word,
                self.ui and self.ui.highlight) then
            capture = self._flipside_pending_context
        end
        if type(capture) == "table" then
            prev_context = capture.prev_context
            next_context = capture.next_context
            highlight = util.cleanupSelectedText(capture.selected or "")
        else
            -- Restore the original FlipSide v0.1.0 reading-context capture:
            -- request KOReader's selection context directly at addition time.
            -- Unlike the newer fallback, don't require the selected inflection
            -- to equal the dictionary's lemma (e.g. "running" vs "run").
            -- This path only runs when there is no successful snapshot.
            local reading_highlight = self.ui and self.ui.highlight
            if reading_highlight and type(reading_highlight.getSelectedWordContext) == "function" then
                local ok, p, n = pcall(reading_highlight.getSelectedWordContext,
                    reading_highlight, 15)
                if ok then
                    prev_context, next_context = p, n
                    local selected = reading_highlight.selected_text
                    if selected and type(selected.text) == "string" and selected.text ~= "" then
                        highlight = util.cleanupSelectedText(selected.text)
                    end
                else
                    logger.warn("FlipSide legacy context fallback failed:", p)
                end
            end
        end
    end
    if prev_context == "" then prev_context = nil end
    if next_context == "" then next_context = nil end
    if highlight == "" then highlight = nil end

    local update = function() DB:insertOrUpdate({
        book_title = title,
        time = os.time(),
        word = word,
        prev_context = prev_context,
        next_context = next_context,
        highlight = highlight ~= word and highlight or nil
    }) end

    local item = DB:hasWord(word)
    local context_refresh = nil
    if item and settings.with_context and type(highlight) == "string"
        and highlight ~= "" and type(item.book_title) == "string"
        and item.book_title == title then
        local stored_form = (type(item.highlight) == "string" and item.highlight ~= "")
            and item.highlight or item.word
        local function compareText(s)
            return (type(s) == "string" and s or "")
                :lower():gsub("%s+", " "):gsub("^%s+", ""):gsub("%s+$", "")
        end
        local old_prev, old_next = compareText(item.prev_context), compareText(item.next_context)
        local new_prev, new_next = compareText(prev_context), compareText(next_context)
        -- Restore only sides that strictly extend the old excerpt; do not
        -- discard a long saved right context when rescuing a short left one.
        local better_prev = #new_prev > #old_prev and
            (old_prev == "" or new_prev:sub(-#old_prev) == old_prev)
        local better_next = #new_next > #old_next and
            (old_next == "" or new_next:sub(1, #old_next) == old_next)
        local same_selection = compareText(highlight) == compareText(stored_form)
        if same_selection and (better_prev or better_next) then
            context_refresh = function()
                DB:updateContextOnly(word,
                    better_prev and prev_context or nil,
                    better_next and next_context or nil,
                    highlight)
            end
        end
    end
    if item then
        local date_str = T(_("Added on %1"), os.date("%Y-%m-%d", item.create_time))
        local time_str = T(_("Review scheduled at %1"), os.date("%Y-%m-%d %H:%M", item.due_time))
        local dialog = WordInfoDialog:new{
            title = _("Vocabulary exists:") .. " " .. word,
            word = word,
            highlighted_word = item.highlight or word,
            book_title = item.book_title,
            dates = date_str .. " | " .. time_str,
            prev_context = item.prev_context,
            next_context = item.next_context,
            update_callback = update,
            refresh_context_callback = context_refresh,
            forgot_callback = function()
                DB:gotOrForgot(item, false)
                DB:batchUpdateItems({ item })
            end,
            got_it_callback = function()
                DB:gotOrForgot(item, true)
                DB:batchUpdateItems({ item })
            end,
        }
        UIManager:show(dialog)
    else
        update()
    end

    return true
end

return VocabBuilder
